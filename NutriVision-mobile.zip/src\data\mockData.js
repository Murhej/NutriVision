// Mock data for all screens — realistic sample data for the NutriVision app

export const USER_PROFILE = {
  name: 'Alex Johnson',
  avatar: require('../../assets/profile-avatar.png'),
  initials: 'AJ',
  email: 'alex.johnson@email.com',
  age: 24,
  height: '5\'10"',
  weight: '165 lbs',
  goal: 'Maintain Weight',
  dailyCalorieGoal: 2000,
  streak: 12,
  totalScans: 87,
  memberSince: 'Jan 2026',
};

export const TODAY_NUTRITION = {
  calories: { consumed: 1420, goal: 2000 },
  protein: { consumed: 68, goal: 120, unit: 'g' },
  carbs: { consumed: 185, goal: 250, unit: 'g' },
  fat: { consumed: 42, goal: 65, unit: 'g' },
  water: { consumed: 6, goal: 8, unit: 'glasses' },
};

export const TODAYS_MEALS = [
  {
    id: '1',
    name: 'Avocado Toast with Eggs',
    time: '8:30 AM',
    type: 'Breakfast',
    calories: 380,
    protein: 18,
    carbs: 32,
    fat: 22,
    image: require('../../assets/healthy-meal.png'),
    emoji: '🥑',
  },
  {
    id: '2',
    name: 'Grilled Chicken Salad',
    time: '12:45 PM',
    type: 'Lunch',
    calories: 520,
    protein: 35,
    carbs: 28,
    fat: 12,
    image: null,
    emoji: '🥗',
  },
  {
    id: '3',
    name: 'Greek Yogurt & Berries',
    time: '3:15 PM',
    type: 'Snack',
    calories: 180,
    protein: 15,
    carbs: 24,
    fat: 3,
    image: null,
    emoji: '🫐',
  },
  {
    id: '4',
    name: 'Salmon Rice Bowl',
    time: '7:00 PM',
    type: 'Dinner',
    calories: 340,
    protein: 0,
    carbs: 101,
    fat: 5,
    image: null,
    emoji: '🍣',
  },
];

export const CALENDAR_DATA = (() => {
  const data = {};
  const today = new Date();
  const year = today.getFullYear();
  const month = today.getMonth();

  for (let d = 1; d <= today.getDate(); d++) {
    const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
    const rand = Math.random();
    if (rand > 0.3) {
      const consumed = Math.floor(1400 + Math.random() * 900);
      data[dateStr] = {
        calories: consumed,
        goal: 2000,
        status: consumed <= 2100 ? 'on-target' : 'over',
      };
    } else {
      data[dateStr] = { calories: 0, goal: 2000, status: 'no-data' };
    }
  }

  // Make today match TODAY_NUTRITION
  const todayStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
  data[todayStr] = { calories: 1420, goal: 2000, status: 'on-target' };

  return data;
})();

export const FEED_ARTICLES = [
  {
    id: '1',
    title: '10 High-Protein Breakfasts to Start Your Day',
    category: 'Nutrition',
    excerpt: 'Fuel your morning with these protein-packed breakfast ideas that keep you full until lunch.',
    readTime: '5 min',
    emoji: '🍳',
    color: '#fef3c7',
  },
  {
    id: '2',
    title: 'How to Read Nutrition Labels Like a Pro',
    category: 'Wellness',
    excerpt: 'Understanding nutrition labels is key to making healthier food choices every day.',
    readTime: '4 min',
    emoji: '📋',
    color: '#dbeafe',
  },
  {
    id: '3',
    title: 'The Benefits of Meal Prepping',
    category: 'Recipes',
    excerpt: 'Save time and eat healthier by planning and preparing your meals in advance.',
    readTime: '6 min',
    emoji: '🥘',
    color: '#dcfce7',
  },
  {
    id: '4',
    title: 'Hydration: Why Water is Your Best Friend',
    category: 'Fitness',
    excerpt: 'Learn why staying hydrated is essential for your body and how much water you really need.',
    readTime: '3 min',
    emoji: '💧',
    color: '#e0e7ff',
  },
  {
    id: '5',
    title: 'Understanding Macronutrients',
    category: 'Nutrition',
    excerpt: 'A deep dive into proteins, carbs, and fats — what they do and how much you need.',
    readTime: '7 min',
    emoji: '📊',
    color: '#fce7f3',
  },
  {
    id: '6',
    title: 'Quick 15-Minute Healthy Dinners',
    category: 'Recipes',
    excerpt: 'No time to cook? These quick dinner recipes are nutritious and ready in minutes.',
    readTime: '5 min',
    emoji: '⏰',
    color: '#fff7ed',
  },
];

export const LEADERBOARD_USERS = [
  { id: '1', name: 'Sarah Miller', initials: 'SM', streak: 45, score: 9800, avatar: null },
  { id: '2', name: 'James Chen', initials: 'JC', streak: 38, score: 8950, avatar: null },
  { id: '3', name: 'Emma Wilson', initials: 'EW', streak: 34, score: 8200, avatar: null },
  { id: '4', name: 'Alex Johnson', initials: 'AJ', streak: 12, score: 5400, isCurrentUser: true, avatar: null },
  { id: '5', name: 'Mike Davis', initials: 'MD', streak: 28, score: 7100, avatar: null },
  { id: '6', name: 'Lisa Park', initials: 'LP', streak: 22, score: 6500, avatar: null },
  { id: '7', name: 'Tom Brown', initials: 'TB', streak: 19, score: 5900, avatar: null },
  { id: '8', name: 'Aisha Khan', initials: 'AK', streak: 15, score: 4800, avatar: null },
  { id: '9', name: 'Carlos Lopez', initials: 'CL', streak: 10, score: 3900, avatar: null },
  { id: '10', name: 'Nina Patel', initials: 'NP', streak: 7, score: 3200, avatar: null },
];

export const ACHIEVEMENTS = [
  { id: '1', title: 'First Scan', emoji: '📸', unlocked: true, description: 'Scanned your first meal' },
  { id: '2', title: '7-Day Streak', emoji: '🔥', unlocked: true, description: 'Logged meals 7 days in a row' },
  { id: '3', title: 'Macro Master', emoji: '💪', unlocked: true, description: 'Hit all macro goals in a day' },
  { id: '4', title: 'Century Club', emoji: '💯', unlocked: false, description: 'Scan 100 meals' },
  { id: '5', title: '30-Day Streak', emoji: '⭐', unlocked: false, description: 'Log meals 30 days straight' },
  { id: '6', title: 'Hydration Hero', emoji: '💧', unlocked: false, description: 'Meet water goal 14 days' },
];

export const FEED_CATEGORIES = ['All', 'Nutrition', 'Fitness', 'Recipes', 'Wellness'];
